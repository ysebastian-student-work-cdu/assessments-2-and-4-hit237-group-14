from django.apps import AppConfig


class Group14AppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'group14_app'
