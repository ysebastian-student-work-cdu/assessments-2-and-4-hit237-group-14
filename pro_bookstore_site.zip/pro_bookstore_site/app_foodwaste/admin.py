from django.contrib import admin

# Register your models here.
from app_foodwaste.models import *

# Register your models here.
myModels = [Organization,Role,User,Location,WasteCat,WasteItem,Audit]
admin.site.register(myModels)