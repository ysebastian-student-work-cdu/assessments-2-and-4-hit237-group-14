from django.shortcuts import render
from django.apps import apps
from .models import *
from .forms import *
from django.http import HttpResponseRedirect
from django.db import models

# APP_MODELS = [model for model in apps.all_models['app_foodwaste'] if not model._meta.is_auto_created and len(model._meta.fields) > 1]
MODELE_FORMS = {Organization:FormOrganization, Role:FormRole, User:FormUser, Location:FormLocation, WasteCat:FormWasteCat, WasteItem:FormWasteItem, Audit:FormAudit}

def get_model_record_to_form(request,model='',pk=''):
    model_class = apps.get_model('app_foodwaste',model)
    a = model_class.objects.get(pk=pk)
    form = MODELE_FORMS[model_class](request.POST,instance=a)
    return form

def model_list(request):
    APP_LABEL = 'app_foodwaste'
    app_models = apps.all_models[APP_LABEL]
    APP_MODELS = [
    model.__name__ for model in app_models.values()
    if not model._meta.auto_created 
    ]
    return render(request, 'app_foodwaste/admin.html',{'app_models':APP_MODELS})

def add(request,model=''):
    i = apps.get_model('app_foodwaste',model)
    submitted = False
    if request.method =='POST':
        form = MODELE_FORMS[i](request.POST)
        if form.is_valid():
            form.save()
            return HttpResponseRedirect('?submitted=True')
    else:
        form = MODELE_FORMS[i]()
        if 'submitted' in request.GET:
            submitted = True 
    return render(request,'app_foodwaste/cred.html', {'f':form,'submitted':submitted,'add':True})

def view(request,model=''):
    model_class = apps.get_model('app_foodwaste',model)
    rows = model_class.objects.filter()
    return render(request,'app_foodwaste/cred.html',{'rows':rows,'model':model,'view':True,'delete':False})
    
def edit(request,model='',pk=''):
    model_class = apps.get_model('app_foodwaste',model)
    a = model_class.objects.get(pk=pk)
    form = MODELE_FORMS[model_class](instance=a)
    if request.method == 'POST':
        if form.is_valid():
            form.save()
            return HttpResponseRedirect('?submitted=True')
    return render(request,'app_foodwaste/edit.html',{'editform':form,'model':model, 'edit':True,'pk':pk})

def save(request, model='',pk=''):
    if request.method == 'POST':
        model_class = apps.get_model('app_foodwaste',model)
        a = model_class.objects.get(pk=pk)
        form=MODELE_FORMS[model_class](request.POST,instance=a)
        if form.is_valid():
            form.save()
        return HttpResponseRedirect('/foodwaste')
 
def delete(request,model=''):
    model_class = apps.get_model('app_foodwaste',model)
    rows = model_class.objects.filter()
    return render(request,'app_foodwaste/cred.html',{'rows':rows,'model':model,'view':False,'delete':True})



    