from django.db import models

# Create your models here.
class Direction(models.Model):
    transmital_ref = models.CharField(max_length=10)
    description = models.CharField(max_length=100)
    date = models.DateField()
    
    
class Variation(models.Model):
    variation_id = models.CharField(max_length=10)
    description = models.CharField(max_length=100)
    direction = models.ManyToManyField(Direction)
    
class SubVariation(models.Model):
    variation_id = models.CharField(max_length=10)
    description = models.CharField(max_length=100)
    