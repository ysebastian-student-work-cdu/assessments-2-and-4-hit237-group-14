from django.contrib import admin
from app_user.models import User

# Register your models here.


# Register your models here.
myModels = [User]
admin.site.register(myModels)