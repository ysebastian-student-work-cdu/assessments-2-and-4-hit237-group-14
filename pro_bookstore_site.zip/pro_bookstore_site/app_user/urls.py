from django.contrib import admin
from django.urls import path, include
from app_user import views

urlpatterns = [
    path('', views.get_name, name='get_name'),
    path('add_user/',views.add_user, name='add_user'),
]