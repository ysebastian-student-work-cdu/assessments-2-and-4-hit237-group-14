from django.contrib import admin
from app_bookstore_pubs.models import Publisher, Author, Book

# Register your models here.
myModels = [Publisher, Author, Book]
admin.site.register(myModels)
