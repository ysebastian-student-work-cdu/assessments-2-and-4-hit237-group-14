from django import forms
from django.forms import ModelForm
from .models import Publisher, Author, Book


class NameForm(forms.Form):
    your_name = forms.CharField(label="Your name", max_length=100)
    your_age = forms.CharField(label="Your age", max_length=100)
    
class ContactForm(forms.Form):
    name = forms.CharField(max_length=100, label='Your Name')
    email = forms.EmailField(required=False, label='Your Email Address')
    subject = forms.CharField(max_length=100)
    message = forms.CharField(widget=forms.Textarea)
    
class PublisherForm(ModelForm):
    required_css_class = 'required'
    class Meta:
        model = Publisher
        fields = '__all__'
        
class AuthorForm(ModelForm):
    required_css_class = 'required'
    class Meta:
        model = Author
        fields = '__all__'
        
class BookForm(ModelForm):
    required_css_class = 'required'
    class Meta:
        model = Book
        fields = '__all__'
        

