from django.shortcuts import render
from app_bookstore_pubs.models import Publisher, Author, Book, MyModel
from django.http import HttpResponseRedirect
from .forms import NameForm, ContactForm, PublisherForm, AuthorForm, BookForm

# Create your views here.
def home(request):
    publisher_attributes = [field.name for field in Publisher._meta.get_fields()]
    return render(request, 'app_bookstore_pubs/home.html',{'publisher_attributes':publisher_attributes})

def add_publisher(request):
    pub = Publisher(
        name='XYZ Inc.',
        address = '101 One Way',
        city = 'Small Town',
        state_provice = 'VIC',
        website='xyz.com'
    )
    
    pub.save()
    
    return render(request,'app_bookstore_pubs/done.html')

def add_publisher_2(request):
    name = request.POST.get('name')
    address  = request.POST.get('address')
    city = request.POST.get('city')
    state_provice = request.POST.get('state_provice')
    website = request.POST.get('website')
    obj = Publisher(
        name=name, 
        address=address,
        city=city, 
        state_provice=state_provice, 
        website=website)
    obj.save()
    
    return render(request, 'app_bookstore_pubs/done.html')
    

def get_name(request):

    form = {'form':NameForm()}
    return render(request, "app_bookstore_pubs/name.html", form)


def contact(request):
    submitted = False
    print(request.POST)
    if request.method =='POST':
        f = ContactForm(request.POST)
        if f.is_valid():
            cd = f.cleaned_data
            return HttpResponseRedirect('/contactform?submited=True')    
    else:
        f = ContactForm()
        if 'submitted' in request.GET:
            submitted = True
        return render(request,'app_bookstore_pubs/contact.html',{"f":f,'submitted':submitted})    
    f = ContactForm()                                        
    return render(request,'app_bookstore_pubs/contact.html',{'f':f})

def done(request):                               
    return render(request, 'app_bookstore_pubs/done.html')

def add_publisher3(request):
    submitted = False
    if request.method =='POST':
        form = PublisherForm(request.POST)
        if form.is_valid():
            form.save()
            return HttpResponseRedirect('/add_publisher/?submitted=True')
    else:
        form = PublisherForm()
        if 'submitted' in request.GET:
            submitted = True 
    return render(request,'app_bookstore_pubs/add_publisher.html', {'f':form,'submitted':submitted})

def add_author(request):
    submitted = False
    if request.method =='POST':
        form = AuthorForm(request.POST)
        if form.is_valid():
            form.save()
            return HttpResponseRedirect('/add_author/?submitted=True')
    else:
        form = AuthorForm()
        if 'submitted' in request.GET:
            submitted = True 
    return render(request,'app_bookstore_pubs/add_author.html', {'f':form,'submitted':submitted})

def add_book(request):
    submitted = False
    if request.method =='POST':
        form = BookForm(request.POST)
        if form.is_valid():
            form.save()
            return HttpResponseRedirect('/add_book/?submitted=True')
    else:
        form = BookForm()
        if 'submitted' in request.GET:
            submitted = True 
    return render(request,'app_bookstore_pubs/add_book.html', {'f':form,'submitted':submitted})