from django.contrib import admin
from django.urls import path, include
from notices import views

# app_name = 'notices'

urlpatterns = [
    path('', views.add_notices,name='add_notices'),
    path('noticeform', views.add_notices,name='add_notices'),
    # path('add_notices', views.add_notices),
]
