from django import forms
from django.forms import ModelForm
from .models import Direction, Variation
    
class DirectionForm(ModelForm):
    required_css_class = 'required'
    class Meta:
        model = Direction
        fields = '__all__'
        widgets = {
            'date': forms.DateInput(attrs={'type': 'date'}),
        }
        
class VariationForm(ModelForm):
    required_css_class = 'required'
    class Meta:
        model = Variation
        fields = '__all__'