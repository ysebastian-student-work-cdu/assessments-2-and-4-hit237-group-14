from django.shortcuts import render
from .forms import DirectionForm,VariationForm
from django.http import HttpResponseRedirect

# Create your views here.
def home(request):
    return render(request, 'notices/home.html')


def add_notices(request):
    submitted = False
    if request.method =='POST':
        form = DirectionForm(request.POST)
        if form.is_valid():
            form.save()
            return HttpResponseRedirect('noticeform?submitted=True')
    else:
        form = DirectionForm()
        if 'submitted' in request.GET:
            submitted = True 
    return render(request,'notices/add_notices.html', {'f':form,'submitted':submitted})