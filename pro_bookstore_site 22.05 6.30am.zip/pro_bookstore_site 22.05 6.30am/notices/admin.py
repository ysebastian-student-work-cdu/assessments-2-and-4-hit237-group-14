from django.contrib import admin

# Register your models here.
from notices.models import Direction, Variation

# Register your models here.
myModels = [Direction,Variation]
admin.site.register(myModels)