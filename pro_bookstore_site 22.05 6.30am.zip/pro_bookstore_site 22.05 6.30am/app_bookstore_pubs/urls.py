from django.contrib import admin
from django.urls import path, include
from app_bookstore_pubs import views

# app_name = "app_bookstore_pubs"

urlpatterns = [
    path('', views.home, name='home'),
    path('add_publisher/', views.add_publisher3, name='add_publisher'),
    path('add_author/', views.add_author, name='add_author'),
    path('add_book/', views.add_book, name='add_book'),
    path('form/',views.get_name, name='get_name'),
    path('user_reg/',include('app_user.urls')),
    path('contactform/',views.contact, name='contact'),
    path('done/',views.done, name='done'),
]