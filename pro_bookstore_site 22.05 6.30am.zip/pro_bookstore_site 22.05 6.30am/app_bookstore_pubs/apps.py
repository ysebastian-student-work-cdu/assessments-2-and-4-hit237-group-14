from django.apps import AppConfig


class AppBookstorePubsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'app_bookstore_pubs'
