from forms import SimpleForm

f = SimpleForm()
print(f)