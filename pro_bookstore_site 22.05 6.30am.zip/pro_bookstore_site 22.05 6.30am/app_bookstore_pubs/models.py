from django.db import models

# Create your models here.
class Publisher(models.Model):
    name = models.CharField(max_length=30)
    address = models.CharField(max_length=50)
    city = models.CharField(max_length=60)
    state_provice = models.CharField(max_length=30)
    website = models.URLField()
    
    def __str__(self):
        return self.name 
    
class Author(models.Model):
    first_name = models.CharField(max_length=30)
    last_name = models.CharField(max_length=40)
    email = models.EmailField()
    
    def __str__(self):
        return u'%s %s'%(self.first_name, self.last_name)
    
class Book(models.Model):
    title = models.CharField(max_length=100)
    authors = models.ManyToManyField(Author)
    publisher = models.ForeignKey(Publisher, on_delete=models.CASCADE)
    
    def __str__(self):
        return str(self.id) + " : " + self.title 
    

class MyModel(models.Model):
    name = models.CharField(max_length=100)
    age = models.IntegerField()
    
    

    

    
'''
you can use the create() shortcut method to achieve the same result:
>>> Event.objects.create(
... name="NYE Party",
... event_date=event_date,
... venue="McIvor's Bar",
... manager="Terry" 
... )

To retrieve all the records in a database table, you use the all() method:
>>> event_list = Event.objects.all()

you retrieve only single records with the get() method. You can retrieve a record using its 
primary key:
>>> Event.objects.get(id=1)
or
>>> Event.objects.get(name="Xmas Barbeque")

Retrieve Multiple Records
>>> Event.objects.filter(manager="Bob")
<QuerySet [<Event: Test Event1>, <Event: Xmas Barbeque>]>

Event.objects.filter(manager="Bob", venue="Notareal Park")

Event.objects.filter(manager="Bob", name__contains="Xmas")
 
get all the records
>>> Event.objects.filter()

Event.objects.order_by("name")

if you want to sort in descending order, you add a minus (-) sign before the field 
name:
>>> Event.objects.order_by("-name")

You can also sort by multiple fields:
>>> Event.objects.order_by("manager", "name")

It’s very common to want to set a sort order on a subset of your database records. You 
achieve this in Django by chaining lookups. This is best illustrated with an example:
>>> Event.objects.filter(manager="Bob").order_by("name")

You can even specify a subset of records to retrieve:
>>> Event.objects.all()[1:3]

To get around this limitation, you use a reverse sort:
>>> Event.objects.filter(manager="Bob").order_by("-event_date")[0]

To update records, you change the instance data and call the save() method again. 
Each subsequent call to the save() method will update the record:
>>> event_date = datetime(2020,9,8,17,0, tzinfo=timezone.utc)
>>> event4.event_date = event_date
>>> event4.save()

best way to update
Event.objects.filter(id=4).update(event_date=event_date)
Event.objects.filter(venue="McIvor's Bar").update(venue="Ripemoff Casino")


to delete a record from the database, you use the delete() method:
>>> Event.objects.filter(name__contains="Test").delete()

you can delete multiple objects by using a filter that returns more than one record:
>>> Event.objects.filter(manager="Terry").delete()

And you can delete all the records in a table with the all() method:
>>> Event.objects.all().delete()


'''
    