from django.shortcuts import render,redirect
from .forms import UserForm
from .models import User

# Create your views here.

def get_name(request):
    form = {'form':UserForm()}
    return render(request, "user_reg.html", form)

def add_user(request):
    if request.method == 'POST':
        form = UserForm(request.POST)
        if form.is_valid():
            my_model = User()
            my_model.name = form.cleaned_data['name']
            my_model.address = form.cleaned_data['address']
            my_model.city = form.cleaned_data['city']
            my_model.state_provice = form.cleaned_data['state_provice']
            my_model.save()
            return render(request, 'done.html')
        
    else:
        form = UserForm()
        return render(request, 'done.html')

