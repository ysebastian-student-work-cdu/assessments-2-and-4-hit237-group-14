from django import forms
from django.forms import ModelForm
from app_user.models import User



# class UserForm(forms.Form):

#     user_name = forms.CharField(label="Name", max_length=100)
#     user_address = forms.CharField(label="Address", max_length=100)
#     user_city = forms.CharField(label="City", max_length=100)
#     user_state = forms.CharField(label="State", max_length=100)
#     user_email = forms.CharField(label="email", max_length=100)
    
class UserForm(ModelForm):
    class Meta:
        model = User
        fields = ['name','address','city','state_provice']

